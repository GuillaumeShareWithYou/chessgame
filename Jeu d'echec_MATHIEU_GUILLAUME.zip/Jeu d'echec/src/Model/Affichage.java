
package Model;
public enum Affichage {
    MENU,
    IDENTIFICATION,
    JEU,
    FIN_DE_PARTIE
}
