
package Model;


public enum Couleur {
    BLANC,
    NOIR
}
